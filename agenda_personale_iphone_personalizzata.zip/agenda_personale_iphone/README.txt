# La mia agenda — versione personalizzata

Stile: crema e verde salvia.
Funzioni:
- schermata Oggi
- calendario mensile con indicatori per i giorni pieni
- appuntamenti con ora, note e scelta del promemoria
- lista di cose da fare con priorità e spunta completamento
- modifica ed eliminazione delle voci
- salvataggio locale nel browser del dispositivo
- richiesta del permesso notifiche

## Importante sulle notifiche
Questa è una web app personale, non un'app nativa. I promemoria usano notifiche del browser programmate mentre l'app è aperta. iOS può sospendere una web app in background: non sono quindi garantiti se l'app è chiusa o sospesa. Per notifiche affidabili anche a app chiusa servirebbe una soluzione nativa o un sistema di notifiche push/server.

## Come usarla su iPhone
1. Pubblica questi file su un hosting statico HTTPS.
2. Apri l'indirizzo in Safari sull'iPhone.
3. Tocca Condividi > Aggiungi alla schermata Home.
4. Apri l'icona dalla schermata Home.
5. Vai su Oggi > Attiva le notifiche e concedi il permesso.
6. Quando crei un appuntamento, scegli il promemoria desiderato.

## Pubblicazione gratuita con GitHub Pages
1. Crea o accedi a un account GitHub.
2. Crea un nuovo repository pubblico, per esempio `la-mia-agenda`.
3. Carica nella radice i file `index.html`, `manifest.json` e `sw.js`.
4. In Settings > Pages, scegli di pubblicare dal branch `main`, cartella `/ (root)`, poi salva.
5. Attendi che GitHub Pages mostri l'indirizzo HTTPS del sito e aprilo in Safari sull'iPhone.

## Privacy e limiti
I dati restano nel local storage del browser sul dispositivo. Non c'è account, backup o sincronizzazione con Calendario Apple. Se cancelli i dati del sito o cambi browser, potresti perderli. Non inserire informazioni sensibili. Le notifiche web non sono garantite quando iOS sospende l'app.
